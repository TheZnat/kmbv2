interface User {
  id: string;
  name: string;
}

export interface IVideoStreamsProps {
  users: User[];
}
