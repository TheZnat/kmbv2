export interface IChatToggleButtonProps {
    isChatVisible: boolean;
    toggleChatVisibility: () => void;
}