export interface FormProps {
  onSubmit: (name: string) => void;
  disabled: boolean;
}
