export interface IMessage {
  name: string;
  messageId: string;
  userId: string;
  createdAt: string;
  messageText: string;
}
