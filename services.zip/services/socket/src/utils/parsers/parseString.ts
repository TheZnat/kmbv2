export const parseString = (str: string | undefined, def: string): string => (
    str || def
);
