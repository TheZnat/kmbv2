export const NAME_MAX_LENGTH = 128;
